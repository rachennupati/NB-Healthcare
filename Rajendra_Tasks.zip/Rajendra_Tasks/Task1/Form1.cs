﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Task1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
        #region Approch  1
        private void button1_Click(object sender, EventArgs e)
        {
            int MatrixRow = Convert.ToInt32(textBox1.Text);

            int MatrixCol = Convert.ToInt32(textBox2.Text);

            string[] inputvalues = textBox3.Text.Split(' ');

            List<string> temp1 = new List<string>();
            List<string> temp2 = new List<string>();            
            string returnResult = "";           

            for(int i=0;i< inputvalues.Length; i++)
            {    
                
                if (i%MatrixCol==0)
                {
                    temp1.Add(inputvalues[i]);
                }
                else
                {
                    temp2.Add(inputvalues[i]);
                }
            }

            foreach(var item in temp1)
            {
                returnResult += item + ",";
            }

            foreach (var item in temp2)
            {
                returnResult += item + ",";
            }

            label1.Text = "Result: "+ returnResult.Remove(returnResult.Length - 1, 1);

        }
        #endregion

        #region Dynamic Approch
        private void Approch2()
        {
           
                int MatrixRow = Convert.ToInt32(textBox1.Text);

                int MatrixCol = Convert.ToInt32(textBox2.Text);

                string[] inputvalues = textBox3.Text.Split(' ');

                List<string[]> temp1 = new List<string[]>();

                string returnResult = "";
                List<string> temp2 = new List<string>();




                for (int i = 0; i < inputvalues.Length; i++)
                {
                    int tempLength = i % MatrixCol;

                    if (tempLength == 0 && i != 0)
                    {
                        temp1.Add(temp2.ToArray());
                        temp2.Clear();
                        temp2.Add(inputvalues[i]);

                    }
                    else
                    {
                        temp2.Add(inputvalues[i]);
                    }

                    if (i == inputvalues.Length - 1)
                    {
                        temp1.Add(temp2.ToArray());
                    }

                }


                for (int i = 0; i < temp1.Count; i++)
                {

                    for (int j = i; j < MatrixCol; j++)
                    {
                        returnResult += temp1[j] + ",";
                    }

                }

              

                label1.Text = "Result: " + returnResult.Remove(returnResult.Length - 1, 1);

           
        }
        #endregion

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
