﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Task2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
   
        private void button1_Click(object sender, EventArgs e)
        {

            int change = (100 - Convert.ToInt32(textBox1.Text));
            int amount = change;
            int[] notes = new int[] { 7,2,1 };
            int[] noteCounter = new int[3];
            
            for (int i = 0; i < 3; i++)
            {
                if (amount >= notes[i])
                {
                    noteCounter[i] = amount / notes[i];
                    amount = amount - noteCounter[i] * notes[i];
                }
            }          

            string result = "";         
            for (int i = 0; i < 3; i++)
            {
                if (noteCounter[i] != 0)
                {
                    result+=notes[i] + " : "
                        + noteCounter[i]+ "\r\n";
                }
            }

            label3.Text = "Change: " + change;
            label2.Text = "Currency Count \r\n"+ result;
        }
    }
}
