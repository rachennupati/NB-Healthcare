﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Task3.Infrastructure;

namespace Task3.Controllers
{

    [ApiController]
    public class MemberController : ControllerBase
    {
        private IMemberRepository _member;
        public MemberController(IMemberRepository member)
        {
            _member = member;
        }
        [HttpGet]
        [Route("api/Member/MemberSearch/{id}")]
        public IActionResult MemberSearch(int id)
        {
            var result = _member.GetMembesByTechnologyId(id);
            return Ok(result);
        }

        [HttpGet]
        [Route("api/Member/MemberDetails/{id}")]
        public IActionResult MemberDetails(int id)
        {

            var result = _member.GetMemberByMemberId(id);
            return Ok(result);
        }

        [HttpGet]
        [Route("api/Member/EligibilityCategory/{id}")]
        public IActionResult EligibilityCategory(int id)
        {

            var result = _member.EligibilityCategory(id);
            return Ok(result);
        }

        

    }
}