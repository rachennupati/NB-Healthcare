﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Task3.DTO;
using Task3.Model;

namespace Task3.Infrastructure
{
    public interface IMemberRepository
    {
        List<MemberDTO> GetMembesByTechnologyId(int id);
        Member GetMemberByMemberId(int id);

        List<Member> EligibilityCategory(int technologyId);
    }
}
