﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Task3.Data;
using Task3.DTO;
using Task3.Infrastructure;
using Task3.Model;

namespace Task3.Services
{
    public class MemberRepository : IMemberRepository
    {
        private ApplicationDbContext _db;

        public MemberRepository(ApplicationDbContext db)
        {
            _db = db;
        }

        public List<Member> EligibilityCategory(int technologyId)
        {
                              

            return _db.member.Where(X => X.Yearsofexperience >= 3 && X.TechnologyID== technologyId && X.DateOfBorth.Year<=DateTime.Now.AddYears(-25).Year).ToList();
            

        }

        public Member GetMemberByMemberId(int id)
        {
            return _db.member.Where(X => X.MemberID == id).FirstOrDefault();
        }

        public List<MemberDTO> GetMembesByTechnologyId(int id)
        {

            return _db.member.Where(X => X.TechnologyID == id).Select(X => new MemberDTO( X.MemberID,X.MemberName )).ToList();
        }

       
    }
}
