﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Task3.DTO
{
    public class MemberDTO
    {
        public MemberDTO(int id,string name):base()
        {
            Id = id;
            Name = name;
        }
        public MemberDTO()
        {

        }
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
