﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Task3.Model
{
    public class Member
    {

		[Key]
		[Required]
		public int MemberID { get; set; }

		[Required]
		public string MemberName { get; set; }

		[Required]
		public int TechnologyID { get; set; }

		[Required]
		public DateTime DateOfBorth { get; set; }

		[Required]
		public string Qualification { get; set; }

		[Required]
		public int Yearsofexperience { get; set; }


		[ForeignKey("TechnologyID")]
		public Technology technology { get; set; }



	}
}
